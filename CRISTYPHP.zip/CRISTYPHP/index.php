<?php
$title = 'Index';
require_once 'includes/header.php';
?>

<h1 class="text-center" style="color: BLUE;">Registration for IT Conference</h1>


<form>
<form action="/action_page.php">
  <label for="fname">First name:</label><br>
  <input type="text" id="fname" name="fname" value="Cristy"><br>
  <label for="lname">Last name:</label><br>
  <input type="text" id="lname" name="lname" value="luyas"><br><br>
</form> 

<form>
<form action="/action_page.php">
  <label for="birthday">Birthday:</label>
  <input type="date" id="birthday" name="birthday">
</form>

<form>
<form action="/action_page.php">
<div class="form-group">
    <label for="Select">Specialty:</label>
    <select class="form-control" id="exampleFormControlSelect1">
      <option>Database Admin</option>
      <option>Software Developer</option>
      <option>Web Developer</option>
      <option>Other</option>
    </select>
  </div>
</form>

<form>
  <div class="form-group">
    <label for="exampleFormControlInput1">Email address:</label>
    <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="cristyluyas@example.com">
  </div>
</form>

  <form>
  <div class="form-group">
    <label for="exampleFormControlInput1">Contact Number:</label>
    <input type="contact-number" class="form-control" id="exampleFormControlInput1" placeholder="">
  </div>
</form>


<?php require_once 'includes/footer.php'?>







